const express = require('express')
const app = express()
app.listen(3000)

var n1 = 888
var n2 = 999999
